package com.pdfsearchpro.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "PDFSearchPro";
    private static final String PREFS = "pdfsearchpro_prefs";
    private static final String KEY_SCAN_TREE_URI = "scan_tree_uri";

    private WebView webView;
    private ActivityResultLauncher<Uri> folderPickerLauncher;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        // Registers the system folder-picker (Storage Access Framework).
        // The user grants access to one folder (e.g. Downloads); we persist
        // that permission so future scans don't ask again.
        folderPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocumentTree(),
                (Uri treeUri) -> {
                    if (treeUri == null) {
                        runOnUiThread(() -> webView.evaluateJavascript(
                                "receiveScanError('No folder selected')", null));
                        return;
                    }
                    getContentResolver().takePersistableUriPermission(
                            treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    getPrefs().edit().putString(KEY_SCAN_TREE_URI, treeUri.toString()).apply();
                    scanTreeAndSendToWeb(treeUri);
                });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private SharedPreferences getPrefs() {
        return getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Exposed to JavaScript as window.AndroidBridge */
    private class AndroidBridge {
        @JavascriptInterface
        public void scanForPdfs() {
            String saved = getPrefs().getString(KEY_SCAN_TREE_URI, null);
            if (saved != null) {
                Uri treeUri = Uri.parse(saved);
                boolean stillGranted = false;
                for (android.content.UriPermission perm : getContentResolver().getPersistedUriPermissions()) {
                    if (perm.getUri().equals(treeUri) && perm.isReadPermission()) {
                        stillGranted = true;
                        break;
                    }
                }
                if (stillGranted) {
                    scanTreeAndSendToWeb(treeUri);
                    return;
                }
            }
            runOnUiThread(() -> folderPickerLauncher.launch(null));
        }
    }

    private void scanTreeAndSendToWeb(Uri treeUri) {
        new Thread(() -> {
            try {
                DocumentFile root = DocumentFile.fromTreeUri(this, treeUri);
                List<DocumentFile> pdfDocs = new ArrayList<>();
                if (root != null) collectPdfs(root, pdfDocs);

                int sentCount = 0;
                for (DocumentFile doc : pdfDocs) {
                    try (InputStream in = getContentResolver().openInputStream(doc.getUri())) {
                        if (in == null) continue;
                        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                        byte[] chunk = new byte[8192];
                        int read;
                        while ((read = in.read(chunk)) != -1) buffer.write(chunk, 0, read);

                        String nameB64 = Base64.encodeToString(
                                doc.getName().getBytes("UTF-8"), Base64.NO_WRAP);
                        String dataB64 = Base64.encodeToString(
                                buffer.toByteArray(), Base64.NO_WRAP);

                        // One call per file — sending every PDF combined into a
                        // single huge JS string was unreliable for larger
                        // libraries, so each file is pushed to the page
                        // separately as soon as it's read.
                        runOnUiThread(() -> webView.evaluateJavascript(
                                "receivePdfFromNative('" + nameB64 + "','" + dataB64 + "')", null));
                        sentCount++;
                    } catch (Exception readErr) {
                        Log.e(TAG, "Failed reading " + doc.getName(), readErr);
                    }
                }

                final int finalCount = sentCount;
                runOnUiThread(() -> webView.evaluateJavascript(
                        "receiveScanComplete(" + finalCount + ")", null));
            } catch (Exception e) {
                Log.e(TAG, "Scan failed", e);
                runOnUiThread(() -> webView.evaluateJavascript(
                        "receiveScanError('Auto scan failed')", null));
            }
        }).start();
    }

    /** Recursively walks a SAF folder tree collecting .pdf documents. */
    private void collectPdfs(DocumentFile dir, List<DocumentFile> out) {
        for (DocumentFile child : dir.listFiles()) {
            if (child.isDirectory()) {
                collectPdfs(child, out);
            } else if (child.getName() != null
                    && child.getName().toLowerCase().endsWith(".pdf")) {
                out.add(child);
            }
        }
    }
}
